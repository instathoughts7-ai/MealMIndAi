/**
 * MealPlannerService - Client-side interface to handle meal plan requests
 */
import { UserPlannerInput, MealPlanResponse } from '../types/mealPlan';
import { validatePlannerInput, sanitizeIngredientsList } from '../utils/validation';

export class MealPlannerService {
  /**
   * Generates a meal plan by calling the backend API after validation & sanitization
   */
  public static async generateMealPlan(input: UserPlannerInput): Promise<MealPlanResponse> {
    // 1. Validate inputs before calling the API
    const validation = validatePlannerInput(input);
    if (!validation.isValid) {
      const firstErrorKey = Object.keys(validation.errors)[0];
      throw new Error(`Validation Error: ${validation.errors[firstErrorKey]}`);
    }

    // 2. Sanitize complex inputs
    const sanitizedInput: UserPlannerInput = {
      ...input,
      availableIngredients: sanitizeIngredientsList(input.availableIngredients),
    };

    try {
      // 3. Make server call
      const response = await fetch('/api/mealplan', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(sanitizedInput),
      });

      if (!response.ok) {
        let errorMessage = `Server error (Status ${response.status})`;
        try {
          const errorJson = await response.json();
          if (errorJson?.error) {
            errorMessage = errorJson.error;
          }
        } catch {
          // ignore parsing error, use fallbacks
        }
        throw new Error(errorMessage);
      }

      const mealPlan: MealPlanResponse = await response.json();
      return mealPlan;
    } catch (error: unknown) {
      if (error instanceof Error) {
        throw error;
      }
      throw new Error('An unexpected network error occurred while generating the meal plan.');
    }
  }
}
