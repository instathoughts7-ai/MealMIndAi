/**
 * Input validation and sanitization functions for MealMind AI
 */
import { UserPlannerInput, ValidationResult } from '../types/mealPlan';

/**
 * Sanitizes input text using a robust ALLOW-LIST mechanism to absolutely prevent script injection
 * and reject characters commonly used in scripting bypasses.
 * Returns only safe alphanumeric string segments.
 */
export function sanitizeString(input: string): string {
  if (!input) return '';
  
  // 1. Strip standard HTML/XML tag markers
  const withoutTags = input.replace(/<[^>]*>/g, '');
  
  // 2. Filter characters via robust ALLOW-LIST validation:
  // Allow letters, numbers, standard single spaces, commas, hyphens, periods, single quotes, and parentheses.
  // This explicitly strips control characters, semi-colons, double quotes, angle brackets, curly braces, and backslashes.
  const ALLOW_LIST_REGEX = /[a-zA-Z0-9\s,\.\-\'()]/;
  let clean = '';
  for (let i = 0; i < withoutTags.length; i++) {
    const char = withoutTags[i];
    if (ALLOW_LIST_REGEX.test(char)) {
      clean += char;
    }
  }
  
  // 3. Normalize spaces: Trim start/end and map consecutive whitespace to a single space
  return clean.trim().replace(/\s+/g, ' ');
}

/**
 * Parses, clean-filters, and optimizes input food stocks / ingredients.
 * Applies word and item deduplication, input length caps, and whitespace normalization
 * to optimize token usage when sending downstream to the Gemini LLM engine.
 *
 * Example: " tomato     tomato     onion " -> "Tomato, Onion"
 */
export function sanitizeIngredientsList(rawIngredients: string): string {
  if (!rawIngredients) return '';

  // Limit raw input to max 2000 characters to prevent excessive payloads (malformed mitigation)
  const truncatedRaw = rawIngredients.slice(0, 2000);
  
  // Split on potential boundaries: newline or comma
  const segments = truncatedRaw.split(/[,\n]+/);
  
  const uniqueItems = new Set<string>();
  
  for (const segment of segments) {
    // 1. Sanitize the string item with our strict allow-list
    const sanitized = sanitizeString(segment);
    if (!sanitized) continue;
    
    // 2. Handle sub-word tokens inside the element (e.g., "tomato tomato onion")
    // Split by spaces to find word targets
    const words = sanitized.split(' ');
    const uniqueWordsInItem: string[] = [];
    
    for (const word of words) {
      const lowerWord = word.toLowerCase();
      // Remove excessive repetition of exact same word inside a single segment
      // Example: "tomato tomato" -> "tomato"
      if (lowerWord && !uniqueWordsInItem.includes(lowerWord)) {
        uniqueWordsInItem.push(lowerWord);
      }
    }
    
    // If we have some valid words
    if (uniqueWordsInItem.length > 0) {
      // Re-construct the segment with normal capitalization (Title Case)
      const capitalizedItem = uniqueWordsInItem
        .map(w => w.charAt(0).toUpperCase() + w.slice(1))
        .join(' ');
        
      if (capitalizedItem && !uniqueItems.has(capitalizedItem)) {
        uniqueItems.add(capitalizedItem);
      }
    }
  }
  
  // Convert back to Array
  const finalArray = Array.from(uniqueItems);
  
  // 3. Limit the total number of items to prevent super excessive payloads
  const maxAllowedItems = finalArray.slice(0, 30);
  
  // 4. Return formatted comma list
  return maxAllowedItems.join(', ');
}

/**
 * Validates the full planner input form payload
 */
export function validatePlannerInput(input: UserPlannerInput): ValidationResult {
  const errors: Record<string, string> = {};

  // Budget Validation
  if (typeof input.dailyBudget !== 'number' || isNaN(input.dailyBudget)) {
    errors.dailyBudget = 'Budget must be a valid number.';
  } else if (input.dailyBudget <= 0) {
    errors.dailyBudget = 'Daily budget must be greater than zero.';
  } else if (input.dailyBudget > 10000) {
    errors.dailyBudget = 'Let us keep the daily budget practical (maximum $10,000).';
  }

  // Family Size Validation
  if (typeof input.familySize !== 'number' || isNaN(input.familySize)) {
    errors.familySize = 'Family size must be a valid number.';
  } else if (!Number.isInteger(input.familySize)) {
    errors.familySize = 'Family size must be a whole number.';
  } else if (input.familySize < 1) {
    errors.familySize = 'Family size must be at least 1 person.';
  } else if (input.familySize > 50) {
    errors.familySize = 'For larger parties (>50), please plan on catering scale.';
  }

  // Cooking Time Validation
  if (typeof input.cookingTimeAvailable !== 'number' || isNaN(input.cookingTimeAvailable)) {
    errors.cookingTimeAvailable = 'Cooking time must be a valid number.';
  } else if (input.cookingTimeAvailable < 1) {
    errors.cookingTimeAvailable = 'Cooking time must be at least 1 minute.';
  } else if (input.cookingTimeAvailable > 1440) {
    errors.cookingTimeAvailable = 'Cooking time cannot exceed 24 hours (1440 mins).';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

/**
 * Client performance-optimized local feedback test for budget status
 */
export function determineBudgetStatus(estimatedCost: number, maxBudget: number): 'Within Budget' | 'Near Limit' | 'Over Budget' {
  if (estimatedCost > maxBudget) {
    return 'Over Budget';
  }
  // If cost is 85% or more of max budget, flag it as near limit
  if (estimatedCost >= maxBudget * 0.85) {
    return 'Near Limit';
  }
  return 'Within Budget';
}

