/**
 * MealMind AI - Comprehensive In-Browser Test Suite
 * Tests: Input validation boundaries, client-server integration loops, string sanitization rules, and budget analysis formulas
 */
import { validatePlannerInput, determineBudgetStatus, sanitizeString, sanitizeIngredientsList } from './validation';
import { UserPlannerInput, TestResult, MealPlanResponse } from '../types/mealPlan';
import { MealPlannerService } from '../services/mealPlannerService';

export function runTestSuite(): TestResult[] {
  const results: TestResult[] = [];

  // --- 1. BUDGET BOUNDARY EDGE CASES ---
  try {
    const testCases = [
      { cost: 84.95, budget: 100, expected: 'Within Budget' as const, desc: 'Cost < 85% of budget' },
      { cost: 85.00, budget: 100, expected: 'Near Limit' as const, desc: 'Exact 85% limit of budget' },
      { cost: 99.99, budget: 100, expected: 'Near Limit' as const, desc: 'Cost very close to budget limit' },
      { cost: 100.00, budget: 100, expected: 'Near Limit' as const, desc: 'Exact 100% budget threshold' },
      { cost: 100.05, budget: 100, expected: 'Over Budget' as const, desc: 'Cost exceeding budget threshold by pennies' },
    ];

    testCases.forEach((tc, idx) => {
      const status = determineBudgetStatus(tc.cost, tc.budget);
      const passed = status === tc.expected;
      results.push({
        name: `Budget Boundary - ${tc.desc} (Cost: $${tc.cost}, Budget: $${tc.budget})`,
        passed,
        message: passed 
          ? `Passed! Evaluated exactly as "${status}".`
          : `Failed! Expected "${tc.expected}", but got "${status}".`,
      });
    });
  } catch (err: any) {
    results.push({ name: 'Budget Boundary Test Suite', passed: false, message: err.message });
  }

  // --- 2. ROBUST SANITIZATION & DUPLICATE REJECTION ---
  try {
    const rawMalicious = '<iframe src="javascript:alert(1)"></iframe> tomato     tomato     onion;   <script>alert("XSS")</script>';
    const cleaned = sanitizeIngredientsList(rawMalicious);
    
    // Check that scripts/tags are removed, and duplicate tomatoes are merged
    const scriptFree = !cleaned.includes('<iframe>') && !cleaned.includes('<script>') && !cleaned.includes(';');
    const deduplicated = cleaned === 'Tomato, Onion';
    const passed = scriptFree && deduplicated;

    results.push({
      name: 'Sanitization & Efficiency - Allow-list Filter and Word Deduplication',
      passed,
      message: passed
        ? `Passed! Nicely normalized input to: "${cleaned}"`
        : `Failed! Injection remains or deduplication failed. Result: "${cleaned}"`,
    });
  } catch (err: any) {
    results.push({ name: 'Sanitization Test Suite', passed: false, message: err.message });
  }

  // --- 3. PAYLOAD VALIDATION CHECKS ---
  try {
    // 3a. Invalid low budget
    const invalidBudget: UserPlannerInput = {
      dailyBudget: 0,
      familySize: 2,
      dietPreference: 'Vegan',
      availableIngredients: '',
      cookingTimeAvailable: 45,
      dayType: 'Working Day',
    };
    const check1 = validatePlannerInput(invalidBudget);
    
    // 3b. Floating-point family members
    const fractionalFamily: UserPlannerInput = {
      ...invalidBudget,
      dailyBudget: 25,
      familySize: 3.5,
    };
    const check2 = validatePlannerInput(fractionalFamily);

    // 3c. Out-of-bounds family members (>50)
    const giantFamily: UserPlannerInput = {
      ...invalidBudget,
      dailyBudget: 25,
      familySize: 99,
    };
    const check3 = validatePlannerInput(giantFamily);

    results.push({
      name: 'Validation Boundaries - Reject Invalid Form Values',
      passed: !check1.isValid && !check2.isValid && !check3.isValid,
      message: `Passed! Correctly blocked zero budget, float family members (3.5), and excessive family size (99).`,
    });
  } catch (err: any) {
    results.push({ name: 'Payload Validation Suite', passed: false, message: err.message });
  }

  // --- 4. SERVER INTEGRATION MOCK - /api/mealplan SUCCESS ---
  try {
    const backupFetch = globalThis.fetch;
    const testInput: UserPlannerInput = {
      dailyBudget: 60,
      familySize: 3,
      dietPreference: 'Vegetarian',
      availableIngredients: 'rice, onion',
      cookingTimeAvailable: 30,
      dayType: 'Working Day',
    };

    const mockSuccessResponse: MealPlanResponse = {
      breakfast: { mealName: 'Mocha Oats', prepTime: '10 mins', cost: 5.0, description: 'Budget oats', recipeSteps: ['Stir'] },
      lunch: { mealName: 'Lentils & Rice', prepTime: '15 mins', cost: 10.0, description: 'Quick lentils', recipeSteps: ['Boil'] },
      dinner: { mealName: 'Tofu Sauté', prepTime: '15 mins', cost: 15.0, description: 'Fast stir fry', recipeSteps: ['Sauté'] },
      groceryList: { alreadyAvailable: ['Rice', 'Onion'], needToBuy: [] },
      substitutions: [],
      budgetAnalysis: { estimatedDailyCost: 30.0, remainingBudget: 30.0, budgetStatus: 'Within Budget', feasibilityExplanation: 'Good', savingsTips: [] },
    };

    // Swap network fetch dynamically with a mock success handler
    globalThis.fetch = async (url: string | URL | Request, options?: RequestInit) => {
      if (url === '/api/mealplan' && options?.method === 'POST') {
        const body = JSON.parse(options.body as string);
        // Ensure that inputs are properly formatted and normalized before the api call
        if (body.availableIngredients === 'Rice, Onion') {
          return {
            ok: true,
            status: 200,
            json: async () => mockSuccessResponse,
          } as Response;
        }
      }
      return { ok: false, status: 400 } as Response;
    };

    // Execute through frontend service loop
    (async () => {
      try {
        const res = await MealPlannerService.generateMealPlan(testInput);
        const loopPassed = res.breakfast.mealName === 'Mocha Oats' && res.budgetAnalysis.estimatedDailyCost === 30.0;
        results.push({
          name: 'Integration Loop - API Success & Serialized Response Processing',
          passed: loopPassed,
          message: loopPassed 
            ? 'Passed! Successfully validated, sanitized inputs, posted payload, and compiled meal plan response.'
            : 'Failed! Recieved unexpected response values from service integration.',
        });
      } catch (e: any) {
        results.push({ name: 'Integration Loop - API Success', passed: false, message: e.message });
      } finally {
        globalThis.fetch = backupFetch; // Recover real fetch
      }
    })();
  } catch (err: any) {
    results.push({ name: 'API Success Loop Suite', passed: false, message: err.message });
  }

  // --- 5. SERVER INTEGRATION MOCK - /api/mealplan SHIELDED FAILURE ---
  try {
    const backupFetch = globalThis.fetch;
    const testInput: UserPlannerInput = {
      dailyBudget: 40,
      familySize: 2,
      dietPreference: 'Vegan',
      availableIngredients: 'tofu',
      cookingTimeAvailable: 20,
      dayType: 'Working Day',
    };

    // Swap fetch with a server-level failure (500) mimicking our newly genericized response
    globalThis.fetch = async (url: string | URL | Request, options?: RequestInit) => {
      if (url === '/api/mealplan' && options?.method === 'POST') {
        return {
          ok: false,
          status: 500,
          json: async () => ({
            error: 'We encountered a problem generating your custom meal plan. Please check your inputs and try again downstream.'
          }),
        } as Response;
      }
      return { ok: false, status: 400 } as Response;
    };

    // Execute API service call asserting that correct generic fault is bubbled
    (async () => {
      try {
        await MealPlannerService.generateMealPlan(testInput);
        results.push({
          name: 'Integration Loop - API Handled Fault Rejection',
          passed: false,
          message: 'Failed! Plan was compiled despite server offering a 500 fault.',
        });
      } catch (e: any) {
        const isShielded = e.message.includes('We encountered a problem generating your custom');
        results.push({
          name: 'Integration Loop - API Handled Fault Rejection',
          passed: isShielded,
          message: isShielded
            ? 'Passed! Server shielded sensitive exception traces and returned safe generic message.'
            : `Failed! Verbose leak identified: "${e.message}"`,
        });
      } finally {
        globalThis.fetch = backupFetch; // Recover real fetch
      }
    })();
  } catch (err: any) {
    results.push({ name: 'API Failure Loop Suite', passed: false, message: err.message });
  }

  // --- 6. LEGACY CALCULATOR CHECKS ---
  try {
    const basicOk = determineBudgetStatus(40, 100) === 'Within Budget';
    results.push({
      name: 'Calculator Logic - Regular Feasibility Rating',
      passed: basicOk,
      message: basicOk ? 'Passed! Expected fee ratings for lower bound cost.' : 'Failed! Incorrect budget calculation tags.',
    });
  } catch (err: any) {
    results.push({ name: 'Legacy Calculator suite', passed: false, message: err.message });
  }

  return results;
}

