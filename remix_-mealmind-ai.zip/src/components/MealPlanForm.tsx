import { useState, FormEvent, useTransition } from 'react';
import { UserPlannerInput } from '../types/mealPlan';
import { validatePlannerInput } from '../utils/validation';
import { DollarSign, Users, Clock, Calendar, Check, Sparkles, Filter } from 'lucide-react';

interface MealPlanFormProps {
  onSubmit: (input: UserPlannerInput) => Promise<void>;
  isLoading: boolean;
}

export function MealPlanForm({ onSubmit, isLoading }: MealPlanFormProps) {
  // Local state initialized with sensible standard budgets/sizes
  const [inputs, setInputs] = useState<UserPlannerInput>({
    dailyBudget: 40,
    familySize: 3,
    dietPreference: 'Vegetarian',
    availableIngredients: 'rice, onion, potato, garlic, spices',
    cookingTimeAvailable: 60,
    dayType: 'Working Day',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showIngredientsHelp, setShowIngredientsHelp] = useState(false);
  const [isPending, startTransition] = useTransition();

  const handleInputChange = (name: keyof UserPlannerInput, value: string | number) => {
    const updatedInputs = { ...inputs, [name]: value };
    setInputs(updatedInputs);

    // Dynamic field-level error clearing
    const validation = validatePlannerInput(updatedInputs);
    if (errors[name]) {
      setErrors((prev) => {
        const next = { ...prev };
        if (validation.isValid || !validation.errors[name]) {
          delete next[name];
        } else {
          next[name] = validation.errors[name];
        }
        return next;
      });
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validation = validatePlannerInput(inputs);

    if (!validation.isValid) {
      setErrors(validation.errors);
      // Accessibility alert: announce errors
      const firstError = Object.values(validation.errors)[0];
      const audioAnnouncement = new SpeechSynthesisUtterance(`Form validation failed. ${firstError}`);
      window.speechSynthesis?.speak(audioAnnouncement);
      return;
    }

    setErrors({});
    startTransition(async () => {
      await onSubmit(inputs);
    });
  };

  const handleSetQuickPreference = (pref: UserPlannerInput['dietPreference']) => {
    handleInputChange('dietPreference', pref);
  };

  const handleSetQuickDayType = (type: UserPlannerInput['dayType']) => {
    handleInputChange('dayType', type);
  };

  const activeLoadingState = isLoading || isPending;

  return (
    <div className="w-full bg-white rounded-2xl shadow-sm border border-slate-200/80 p-6 md:p-8">
      <div className="flex items-center gap-2 mb-6">
        <Filter className="w-5 h-5 text-emerald-600" />
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">
          Configure Your Day
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6" noValidate>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Daily Budget */}
          <div>
            <label 
              htmlFor="dailyBudget" 
              className="block text-sm font-semibold text-slate-800 mb-2"
            >
              Daily Budget (USD) <span className="text-red-500">*</span>
            </label>
            <div className="relative rounded-xl shadow-sm">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <DollarSign className="h-5 w-5 text-slate-400" aria-hidden="true" />
              </div>
              <input
                type="number"
                name="dailyBudget"
                id="dailyBudget"
                min="1"
                max="10000"
                value={inputs.dailyBudget || ''}
                onChange={(e) => handleInputChange('dailyBudget', parseFloat(e.target.value) || 0)}
                className={`block w-full rounded-xl border pl-10 pr-4 py-3 text-slate-900 focus-visible:outline-none focus:ring-2 focus:ring-emerald-500/25 focus:border-emerald-500 transition-all text-sm font-medium ${
                  errors.dailyBudget ? 'border-red-300 bg-red-50/20' : 'border-slate-200 bg-slate-50/30'
                }`}
                placeholder="40"
                aria-describedby={errors.dailyBudget ? 'dailyBudget-error' : undefined}
                required
              />
            </div>
            {errors.dailyBudget && (
              <p 
                className="mt-2 text-xs text-red-600 font-medium flex items-center gap-1" 
                id="dailyBudget-error" 
                role="alert"
              >
                {errors.dailyBudget}
              </p>
            )}
          </div>

          {/* Family Size */}
          <div>
            <label 
              htmlFor="familySize" 
              className="block text-sm font-semibold text-slate-800 mb-2"
            >
              Family / Group Size <span className="text-red-500">*</span>
            </label>
            <div className="relative rounded-xl shadow-sm">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <Users className="h-5 w-5 text-slate-400" aria-hidden="true" />
              </div>
              <input
                type="number"
                name="familySize"
                id="familySize"
                min="1"
                max="50"
                value={inputs.familySize || ''}
                onChange={(e) => handleInputChange('familySize', parseInt(e.target.value, 10) || 0)}
                className={`block w-full rounded-xl border pl-10 pr-4 py-3 text-slate-900 focus-visible:outline-none focus:ring-2 focus:ring-emerald-500/25 focus:border-emerald-500 transition-all text-sm font-medium ${
                  errors.familySize ? 'border-red-300 bg-red-50/20' : 'border-slate-200 bg-slate-50/30'
                }`}
                placeholder="3"
                aria-describedby={errors.familySize ? 'familySize-error' : undefined}
                required
              />
            </div>
            {errors.familySize && (
              <p 
                className="mt-2 text-xs text-red-600 font-medium flex items-center gap-1" 
                id="familySize-error" 
                role="alert"
              >
                {errors.familySize}
              </p>
            )}
          </div>

          {/* Diet Preference */}
          <div>
            <span className="block text-sm font-semibold text-slate-800 mb-2">
              Diet Preferences
            </span>
            <div className="grid grid-cols-3 gap-2" role="group" aria-label="Dietary preference selection">
              {(['Vegetarian', 'Vegan', 'Non-Vegetarian'] as const).map((pref) => {
                const isActive = inputs.dietPreference === pref;
                return (
                  <button
                    key={pref}
                    type="button"
                    onClick={() => handleSetQuickPreference(pref)}
                    className={`text-xs font-semibold py-3 px-2 rounded-xl border transition-all text-center flex flex-col items-center justify-center gap-1.5 focus-visible:outline-none focus:ring-2 focus:ring-emerald-500/25 cursor-pointer ${
                      isActive
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-600'
                    }`}
                    aria-pressed={isActive}
                  >
                    <span>{pref}</span>
                    {isActive && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Cooking Time Available */}
          <div>
            <label 
              htmlFor="cookingTimeAvailable" 
              className="block text-sm font-semibold text-slate-800 mb-2 flex items-center justify-between"
            >
              <span>Max Daily Cooking Time</span>
              <span className="font-mono text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                {inputs.cookingTimeAvailable} mins
              </span>
            </label>
            <div className="flex items-center gap-4 py-1.5">
              <Clock className="w-5 h-5 text-slate-400 shrink-0" aria-hidden="true" />
              <input
                type="range"
                id="cookingTimeAvailable"
                name="cookingTimeAvailable"
                min="10"
                max="180"
                step="5"
                value={inputs.cookingTimeAvailable}
                onChange={(e) => handleInputChange('cookingTimeAvailable', parseInt(e.target.value, 10))}
                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-600 focus-visible:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>
          </div>

          {/* Day Type Selector */}
          <div>
            <span className="block text-sm font-semibold text-slate-800 mb-2">
              Day Type Style
            </span>
            <div className="grid grid-cols-2 gap-3" role="group" aria-label="Day type selection">
              {(['Working Day', 'Weekend'] as const).map((type) => {
                const isActive = inputs.dayType === type;
                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() => handleSetQuickDayType(type)}
                    className={`py-3 px-4 rounded-xl border transition-all text-sm font-medium flex items-center justify-center gap-2 focus-visible:outline-none focus:ring-2 focus:ring-emerald-500/25 cursor-pointer ${
                      isActive
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-600'
                    }`}
                    aria-pressed={isActive}
                  >
                    <Calendar className="w-4 h-4 text-slate-500" />
                    <span>{type}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Empty right column for layout balancing */}
          <div className="hidden md:block"></div>

          {/* Available Ingredients */}
          <div className="md:col-span-2">
            <div className="flex items-center justify-between mb-2">
              <label 
                htmlFor="availableIngredients" 
                className="text-sm font-semibold text-slate-800"
              >
                Ingredients Already in Your Kitchen
              </label>
              <button
                type="button"
                onClick={() => setShowIngredientsHelp(!showIngredientsHelp)}
                className="text-xs text-emerald-600 hover:text-emerald-700 font-medium focus-visible:outline-none focus:underline cursor-pointer"
              >
                {showIngredientsHelp ? 'Hide helper' : 'Show list tips'}
              </button>
            </div>
            {showIngredientsHelp && (
              <p className="mb-2.5 text-xs text-slate-500 bg-slate-50 border border-slate-100 rounded-xl p-3 leading-relaxed">
                Separating ingredients with commas helps the model identify exact food items (e.g. <strong>rice, potato, red onion, chili, tofu</strong>). Available items are used to save money and cut grocery purchase volumes.
              </p>
            )}
            <textarea
              id="availableIngredients"
              name="availableIngredients"
              rows={3}
              value={inputs.availableIngredients}
              onChange={(e) => handleInputChange('availableIngredients', e.target.value)}
              className="block w-full rounded-xl border border-slate-200 bg-slate-50/30 p-4 text-slate-900 focus-visible:outline-none focus:ring-2 focus:ring-emerald-500/25 focus:border-emerald-500 transition-all text-sm font-medium leading-relaxed resize-none placeholder:text-slate-400"
              placeholder="e.g. rice, beans, salt, pepper, oil, egg, butter"
            />
          </div>

        </div>

        {/* Submit Action Container */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={activeLoadingState}
            className={`w-full inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl text-slate-950 font-bold text-base shadow-lg shadow-emerald-500/10 cursor-pointer focus-visible:outline-none focus:ring-2 focus:ring-emerald-500 transition-all duration-200 ${
              activeLoadingState
                ? 'bg-slate-100 border border-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                : 'bg-emerald-400 hover:bg-emerald-300 border border-emerald-500'
            }`}
          >
            {activeLoadingState ? (
              <div className="flex items-center gap-2">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-slate-500" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Analyzing ingredients & compiling budget...</span>
              </div>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>Generate Smart Meal Plan</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
