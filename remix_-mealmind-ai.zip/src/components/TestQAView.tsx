import { useState, useEffect, useRef } from 'react';
import { runTestSuite } from '../utils/tests';
import { TestResult } from '../types/mealPlan';
import { X, Play, ShieldAlert, BadgeCheck, Terminal, AlertTriangle } from 'lucide-react';

interface TestQAViewProps {
  onKeepFocusActive?: boolean; // optional prop tag
  onClose: () => void;
}

export function TestQAView({ onClose }: TestQAViewProps) {
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [hasRun, setHasRun] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Keep reference of current active element
    const previousFocus = document.activeElement as HTMLElement;

    if (containerRef.current) {
      const focusable = containerRef.current.querySelectorAll<HTMLElement>(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      if (focusable.length > 0) {
        // Direct initial focus to the execute or first focusable button
        focusable[0].focus();
      }
    }

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        onClose();
        return;
      }

      if (e.key === 'Tab' && containerRef.current) {
        const focusable = Array.from(
          containerRef.current.querySelectorAll<HTMLElement>(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
          )
        );
        if (focusable.length === 0) return;

        const first = focusable[0];
        const last = focusable[focusable.length - 1];

        if (e.shiftKey) { // Shift + Tab back navigation
          if (document.activeElement === first) {
            last.focus();
            e.preventDefault();
          }
        } else { // Normal Tab forward navigation
          if (document.activeElement === last) {
            first.focus();
            e.preventDefault();
          }
        }
      }
    }

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (previousFocus && typeof previousFocus.focus === 'function') {
        previousFocus.focus();
      }
    };
  }, [onClose]);

  const startTests = () => {
    const results = runTestSuite();
    setTestResults(results);
    setHasRun(true);
  };

  const totalTests = testResults.length;
  const passedTests = testResults.filter((r) => r.passed).length;
  const allPassed = totalTests > 0 && passedTests === totalTests;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        ref={containerRef}
        className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[85vh] animate-scaleUp"
        role="dialog"
        aria-modal="true"
        aria-labelledby="qa-modal-title"
      >
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <Terminal className="w-5 h-5 text-emerald-400" />
            <h2 id="qa-modal-title" className="text-lg font-bold tracking-tight">
              Real-time QA Hackathon Test Sandbox
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close test panel"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          <p className="text-xs text-slate-500 leading-relaxed font-semibold">
            Run the automated sandbox tests directly within the browser container context. These verify calculation functions, string sanitization rules, and bounding limits defined in the prompt.
          </p>

          {!hasRun ? (
            <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
              <Play className="w-10 h-10 text-emerald-500 mx-auto mb-4 animate-pulse" />
              <h3 className="font-bold text-slate-800 text-sm mb-1">
                Tests Ready to Execute
              </h3>
              <p className="text-xs text-slate-500 mb-6">
                Press the execute button to compile and evaluate all test suites.
              </p>
              <button
                onClick={startTests}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-200 cursor-pointer focus-visible:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Execute Suite Tests</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Summary Header */}
              <div className={`p-4 rounded-xl border flex items-center justify-between ${
                allPassed ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-red-50 border-red-200 text-red-800'
              }`}>
                <div className="flex items-center gap-3">
                  {allPassed ? (
                    <BadgeCheck className="w-6 h-6 text-emerald-600" />
                  ) : (
                    <ShieldAlert className="w-6 h-6 text-red-600" />
                  )}
                  <div>
                    <h3 className="font-bold text-sm">
                      {allPassed ? 'All Integrity Tests Passed' : 'Test Failures Identified'}
                    </h3>
                    <p className="text-xs font-semibold opacity-90 mt-0.5">
                      Completed {passedTests} of {totalTests} assertion checks.
                    </p>
                  </div>
                </div>
                <span className={`text-xs font-mono font-bold px-2.5 py-1 rounded-md ${
                  allPassed ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                }`}>
                  {passedTests}/{totalTests} PASS
                </span>
              </div>

              {/* Individual Assertion Items */}
              <div className="space-y-2.5">
                {testResults.map((result, idx) => (
                  <div 
                    key={idx} 
                    className="p-3.5 rounded-xl border border-slate-150 bg-white flex items-start gap-3.5 hover:bg-slate-50/30 transition-colors"
                  >
                    <div className="mt-0.5 shrink-0">
                      {result.passed ? (
                        <div className="w-4.5 h-4.5 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700" aria-label="Passed">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        </div>
                      ) : (
                        <div className="w-4.5 h-4.5 rounded-full bg-red-100 flex items-center justify-center text-red-700" aria-label="Failed">
                          <AlertTriangle className="w-3.5 h-3.5" />
                        </div>
                      )}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-800">
                        {result.name}
                      </h4>
                      {result.message && (
                        <p className="text-[11px] text-slate-500 font-mono mt-1 leading-normal leading-relaxed">
                          {result.message}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Rerun Button */}
              <div className="pt-2 text-right">
                <button
                  onClick={startTests}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  <Play className="w-3 h-3" />
                  <span>Rerun Test Suite</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-4 flex items-center justify-between border-t border-slate-100 shrink-0">
          <span className="text-[10px] text-slate-400 font-bold tracking-wide font-mono">
            NODE RUNTIME TEST SUITE ACTIVE
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
}

// Inlined checklist component icon for clean usage
function CheckCircle2({ className }: { className?: string }) {
  return (
    <svg 
      className={className} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2.5" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  );
}
