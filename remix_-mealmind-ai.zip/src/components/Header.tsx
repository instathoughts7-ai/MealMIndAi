import { ChefHat, HelpCircle } from 'lucide-react';

interface HeaderProps {
  onOpenHelp: () => void;
  onOpenTests: () => void;
}

export function Header({ onOpenHelp, onOpenTests }: HeaderProps) {
  return (
    <header className="w-full bg-white text-slate-900 border-b border-slate-200 shadow-xs" role="banner">
      <div className="max-w-6xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Brand Container */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-sm" aria-hidden="true">
            <ChefHat className="w-5.5 h-5.5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900 font-sans">
                MealMind AI
              </h1>
              <span className="text-[10px] uppercase font-bold tracking-widest bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full border border-emerald-100">
                v1.0
              </span>
            </div>
            <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest mt-0.5">
              Plan. Save. Reduce Waste.
            </p>
          </div>
        </div>

        {/* Global Control Bar */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenTests}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50 text-xs font-semibold text-slate-600 hover:text-emerald-700 transition-all focus-visible:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
            aria-label="Run live application unit tests"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
            Suite Tests
          </button>
          
          <button
            onClick={onOpenHelp}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-600 transition-all focus-visible:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
            aria-label="View user instructions and assistance"
          >
            <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
            Help / Guide
          </button>
        </div>
      </div>
    </header>
  );
}
