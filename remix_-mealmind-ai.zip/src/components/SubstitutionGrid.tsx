import { Substitution } from '../types/mealPlan';
import { RefreshCw, ArrowRight, HelpCircle } from 'lucide-react';

interface SubstitutionGridProps {
  substitutions: Substitution[];
}

export function SubstitutionGrid({ substitutions }: SubstitutionGridProps) {
  if (!substitutions || substitutions.length === 0) {
    return null;
  }

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden h-full flex flex-col">
      {/* Container Header */}
      <div className="px-5 py-4 border-b border-slate-200 bg-slate-50/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <RefreshCw className="w-4 h-4 text-emerald-600 animate-spin-slow" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500">
            Smart Subs
          </h2>
        </div>
      </div>

      <div className="p-5 flex-1 flex flex-col">
        <p className="text-[11px] text-slate-400 mb-4 leading-relaxed font-semibold">
          Swap ingredients for cost-saving pantry alternatives.
        </p>

        {/* Substitutions Vertical Stack */}
        <div className="flex flex-col gap-3 flex-1">
          {substitutions.map((sub, idx) => (
            <div 
              key={idx} 
              className="bg-slate-50 border border-slate-150 rounded-xl p-3 flex flex-col justify-between gap-1.5"
            >
              {/* Core Swap bar */}
              <div>
                <div className="flex justify-between text-[9px] font-bold text-slate-400 tracking-wider mb-1">
                  <span>ORIGINAL</span>
                  <span>REPLACEMENT</span>
                </div>
                <div className="flex justify-between items-center text-xs font-bold">
                  <span className="text-slate-600 truncate max-w-[100px]">{sub.original}</span>
                  <ArrowRight className="w-3 h-3 text-emerald-500 shrink-0" />
                  <span className="text-emerald-650 truncate max-w-[100px]">{sub.substitute}</span>
                </div>
              </div>

              {/* swap rationale detail */}
              <div className="flex gap-1.5 text-[10px] text-slate-500 leading-normal font-medium pt-1.5 border-t border-slate-150">
                <HelpCircle className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
                <p className="line-clamp-2">{sub.reason}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
