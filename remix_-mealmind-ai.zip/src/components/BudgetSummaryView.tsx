import { BudgetAnalysis } from '../types/mealPlan';
import { PiggyBank, HelpCircle, Flame, CheckCircle, TrendingDown, AlertCircle } from 'lucide-react';

interface BudgetSummaryViewProps {
  analysis: BudgetAnalysis;
  targetBudget: number;
}

export function BudgetSummaryView({ analysis, targetBudget }: BudgetSummaryViewProps) {
  // Theme styling configurations matching corresponding indicators
  const statusConfig = {
    'Within Budget': {
      bg: 'bg-emerald-50 border-emerald-250 text-emerald-800',
      badge: 'bg-emerald-500 text-slate-950 font-bold',
      icon: CheckCircle,
      description: 'You are completely within bounds. This menu is highly cost-effective.',
    },
    'Near Limit': {
      bg: 'bg-amber-50 border-amber-250 text-amber-800',
      badge: 'bg-amber-400 text-slate-950 font-bold',
      icon: Flame,
      description: 'Your estimated expenses are nearing your defined daily limit. Splurges should be avoided.',
    },
    'Over Budget': {
      bg: 'bg-red-50 border-red-250 text-red-850',
      badge: 'bg-red-500 text-white font-bold',
      icon: AlertCircle,
      description: 'The estimated required purchases exceed the positive daily ceiling cap.',
    },
  }[analysis.budgetStatus];

  const StatusIcon = statusConfig.icon;

  const costDifference = targetBudget - analysis.estimatedDailyCost;
  const savingsPercent = targetBudget > 0 ? Math.round((costDifference / targetBudget) * 100) : 0;
  const spentPercent = targetBudget > 0 ? Math.min(Math.round((analysis.estimatedDailyCost / targetBudget) * 100), 100) : 0;

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
      <div className="px-6 py-5 border-b border-slate-200 bg-slate-50/50 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <PiggyBank className="w-5 h-5 text-emerald-600" />
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            Budget Status Analysis
          </h2>
        </div>
        <span className={`text-xs uppercase tracking-widest font-extrabold px-3 py-1 rounded-full border ${statusConfig.badge}`}>
          {analysis.budgetStatus}
        </span>
      </div>

      <div className="p-6">
        {/* Bento-style Horizontal Budget Usage Tracker */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
          <div className="flex gap-4 items-center w-full md:w-auto">
            <div className={`h-11 w-11 rounded-full flex items-center justify-center font-bold text-sm shrink-0 shadow-xs ${
              costDifference >= 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
            }`}>
              ${Math.round(analysis.estimatedDailyCost)}
            </div>
            <div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Estimated Cost</p>
              <h3 className={`text-base font-bold ${
                costDifference >= 0 ? 'text-emerald-600' : 'text-red-650'
              }`}>{analysis.budgetStatus}</h3>
            </div>
          </div>
          <div className="flex-1 w-full mx-0 md:mx-6 h-2 bg-slate-200 rounded-full overflow-hidden">
            <div className={`h-full rounded-full transition-all duration-500 ${
              analysis.budgetStatus === 'Over Budget' ? 'bg-red-500' : analysis.budgetStatus === 'Near Limit' ? 'bg-amber-500' : 'bg-emerald-500'
            }`} style={{ width: `${spentPercent}%` }}></div>
          </div>
          <div className="text-right w-full md:w-auto shrink-0 flex md:block justify-between items-center md:text-right">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Remaining</p>
            <p className={`text-base font-mono font-bold ${costDifference >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
              ${costDifference.toFixed(2)}
            </p>
          </div>
        </div>

        {/* Dynamic Status bar message */}
        <div className={`p-4 rounded-xl border flex gap-3.5 items-start mb-6 ${statusConfig.bg}`}>
          <StatusIcon className="w-5 h-5 mt-0.5 shrink-0" />
          <div>
            <h3 className="font-bold text-sm">
              Status assessment: {analysis.budgetStatus}
            </h3>
            <p className="text-xs font-medium leading-relaxed mt-1 opacity-90">
              {statusConfig.description} {analysis.feasibilityExplanation}
            </p>
          </div>
        </div>

        {/* Math Grid Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          
          {/* Target Limit */}
          <div className="bg-slate-50 p-4 border border-slate-200 rounded-xl flex flex-col justify-center">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1">
              Your Target Budget
            </span>
            <span className="text-xl font-bold text-slate-700 font-mono">
              ${targetBudget.toFixed(2)}
            </span>
          </div>

          {/* Current estimated plan cost */}
          <div className="bg-slate-50 p-4 border border-slate-200 rounded-xl flex flex-col justify-center">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1">
              Estimated Meal Cost
            </span>
            <span className="text-xl font-bold text-slate-900 font-mono">
              ${analysis.estimatedDailyCost.toFixed(2)}
            </span>
          </div>

          {/* Balance / Savings */}
          <div className="bg-slate-50 p-4 border border-slate-200 rounded-xl flex flex-col justify-center">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1">
              Calculated Remaining
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className={`text-xl font-bold font-mono ${costDifference >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
                ${costDifference.toFixed(2)}
              </span>
              {costDifference > 0 && (
                <span className="text-[10px] text-emerald-600 font-bold">
                  ({savingsPercent}% saved)
                </span>
              )}
            </div>
          </div>

        </div>

        {/* Frugal Tactics */}
        {analysis.savingsTips && analysis.savingsTips.length > 0 && (
          <div className="border-t border-slate-100 pt-5">
            <div className="flex items-center gap-2 mb-3">
              <TrendingDown className="w-4 h-4 text-emerald-600" />
              <h4 className="text-sm font-bold text-slate-800">
                Frugal Cooking Tactics & Tips
              </h4>
            </div>
            <ul className="list-none space-y-2.5 pl-1" role="list">
              {analysis.savingsTips.map((tip, idx) => (
                <li key={idx} className="flex gap-2.5 text-xs text-slate-600 leading-relaxed font-medium">
                  <span className="select-none text-emerald-500 font-bold">&#8226;</span>
                  <span>{tip}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

      </div>
    </div>
  );
}
