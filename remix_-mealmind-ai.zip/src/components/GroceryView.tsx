import { useState } from 'react';
import { GroceryList } from '../types/mealPlan';
import { Check, ShoppingBag, CheckCircle2, ChevronRight } from 'lucide-react';

interface GroceryViewProps {
  groceryList: GroceryList;
}

export function GroceryView({ groceryList }: GroceryViewProps) {
  // Track check state of dynamic ingredients bought to support standard task checks
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  const toggleCheck = (id: string) => {
    setCheckedItems((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const totalToBuy = groceryList.needToBuy.length;
  const boughtCount = Object.values(checkedItems).filter(Boolean).length;
  const progressPercent = totalToBuy > 0 ? Math.round((boughtCount / totalToBuy) * 100) : 0;

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl shadow-xs overflow-hidden text-white animate-fadeIn">
      {/* List Header */}
      <div className="bg-slate-950 px-6 py-5 flex flex-col md:flex-row md:items-center justify-between gap-3 text-white border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <ShoppingBag className="w-5 h-5 text-emerald-450" />
          <h2 className="text-xl font-bold tracking-tight">
            Grocery Shopping List
          </h2>
        </div>
        {totalToBuy > 0 && (
          <div className="flex items-center gap-2.5">
            <span className="text-xs font-semibold text-slate-405">
              Purchases Checked:
            </span>
            <span className="text-xs bg-emerald-500/10 text-emerald-400 font-extrabold px-2.5 py-1 rounded border border-emerald-500/25 font-mono">
              {boughtCount} / {totalToBuy} ({progressPercent}%)
            </span>
          </div>
        )}
      </div>

      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Section 1: ALREADY AVAILABLE IN THE KITCHEN */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle2 className="w-4.5 h-4.5 text-emerald-400" />
            <h3 className="text-base font-bold text-slate-100">
              Kitchen Pantry Ready
            </h3>
          </div>
          {groceryList.alreadyAvailable && groceryList.alreadyAvailable.length > 0 ? (
            <div className="bg-slate-800/40 border border-slate-800 rounded-xl p-4">
              <ul className="space-y-2.5" role="list">
                {groceryList.alreadyAvailable.map((ingredient, idx) => (
                  <li 
                    key={idx} 
                    className="flex items-center gap-2.5 text-sm font-semibold text-slate-300"
                  >
                    <div className="w-5 h-5 rounded-full bg-emerald-950/80 text-emerald-450 flex items-center justify-center font-bold shrink-0 select-none border border-emerald-500/20">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                    <span>{ingredient}</span>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <p className="text-sm text-slate-400 italic bg-slate-800/20 rounded-xl p-4 border border-slate-800">
              None of the kitchen ingredients specified are directly utilized in this plan.
            </p>
          )}
        </div>

        {/* Section 2: PLANNED GROCERY SHOPPING LIST (NEED TO BUY) */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <ShoppingBag className="w-4.5 h-4.5 text-orange-400" />
            <h3 className="text-base font-bold text-slate-100">
              Needs To Be Bought
            </h3>
          </div>
          {groceryList.needToBuy && groceryList.needToBuy.length > 0 ? (
            <div className="space-y-2">
              {groceryList.needToBuy.map((item, idx) => {
                const uniqueId = `item-${idx}-${item.name}`;
                const isChecked = !!checkedItems[uniqueId];
                return (
                  <div
                    key={idx}
                    onClick={() => toggleCheck(uniqueId)}
                    className={`flex items-center justify-between p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                      isChecked
                        ? 'bg-slate-950/40 border-slate-800/60 opacity-50'
                        : 'bg-slate-800/40 border-slate-800 hover:bg-slate-800/60'
                    }`}
                    role="checkbox"
                    aria-checked={isChecked}
                    tabIndex={0}
                    onKeyDown={(e) => {
                      if (e.key === ' ' || e.key === 'Enter') {
                        e.preventDefault();
                        toggleCheck(uniqueId);
                      }
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-5 h-5 rounded border flex items-center justify-center transition-all shrink-0 ${
                        isChecked 
                          ? 'border-emerald-500 bg-emerald-950/85 text-emerald-400' 
                          : 'border-slate-700 bg-slate-900 text-transparent'
                      }`}>
                        {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                      <div className="flex flex-col">
                        <span className={`text-sm font-semibold transition-all ${
                          isChecked ? 'line-through text-slate-500' : 'text-slate-200'
                        }`}>
                          {item.name}
                        </span>
                        <span className="text-slate-450 text-xs font-semibold mt-0.5 font-mono">
                          Qty: {item.quantity}
                        </span>
                      </div>
                    </div>
                    {/* Estimated Cost badge */}
                    <span className="text-xs font-mono font-bold px-2.5 py-1 bg-slate-900 border border-slate-850 text-slate-350 rounded-lg">
                      ${item.estimatedCost.toFixed(2)}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-sm text-slate-400 italic bg-slate-800/20 rounded-xl p-4 border border-slate-800">
              Excellent news! Everything is readily available in your kitchen. Your budget cost is $0.00.
            </p>
          )}
        </div>

      </div>
    </div>
  );
}
