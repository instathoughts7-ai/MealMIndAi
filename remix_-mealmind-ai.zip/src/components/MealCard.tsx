import { useState } from 'react';
import { MealItem } from '../types/mealPlan';
import { Clock, DollarSign, ChevronDown, ChevronUp, CheckSquare } from 'lucide-react';

interface MealCardProps {
  title: 'Breakfast' | 'Lunch' | 'Dinner';
  meal: MealItem;
  themeColor: 'amber' | 'emerald' | 'indigo';
}

export function MealCard({ title, meal, themeColor }: MealCardProps) {
  const [isOpen, setIsOpen] = useState(false);

  // Theme-specific color classes
  const themeClasses = {
    amber: {
      accent: 'border-amber-200 bg-amber-50/20 text-amber-800',
      badge: 'bg-orange-100 text-orange-700 border-orange-200',
      ring: 'focus:ring-amber-500',
    },
    emerald: {
      accent: 'border-emerald-200 bg-emerald-50/20 text-emerald-800',
      badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      ring: 'focus:ring-emerald-500',
    },
    indigo: {
      accent: 'border-indigo-200 bg-indigo-50/20 text-indigo-800',
      badge: 'bg-purple-100 text-purple-700 border-purple-200',
      ring: 'focus:ring-indigo-500',
    },
  }[themeColor];

  return (
    <article 
      className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden transition-all duration-200 hover:shadow-sm"
      aria-label={`${title} plan: ${meal.mealName}`}
    >
      <div className="p-5 flex flex-col justify-between">
        <div>
          {/* Card Header banner */}
          <div className="flex justify-between items-start mb-3">
            <span className={`px-2 py-1 text-[10px] font-bold rounded uppercase tracking-wider ${themeClasses.badge}`}>
              {title}
            </span>
            <span className="text-xs font-mono text-slate-400 font-extrabold">${meal.cost.toFixed(2)}</span>
          </div>

          <h3 className="font-bold text-base leading-tight text-slate-900 mb-2 truncate">
            {meal.mealName}
          </h3>
          
          <p className="text-xs text-slate-500 mb-4 leading-relaxed line-clamp-3">
            {meal.description}
          </p>

          {/* Badges bar */}
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 mb-4">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span>{meal.prepTime} mins</span>
          </div>
        </div>

        {/* Expandable Recipe Action */}
        <div className="border-t border-slate-100 pt-3">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={`w-full flex items-center justify-between py-1.5 text-xs font-bold text-slate-700 hover:text-emerald-700 transition-colors focus-visible:outline-none focus:ring-2 ${themeClasses.ring} rounded-lg px-1 cursor-pointer`}
            aria-expanded={isOpen}
          >
            <span className="flex items-center gap-1.5">
              <CheckSquare className="w-3.5 h-3.5 text-slate-400" />
              <span>Instructions ({meal.recipeSteps.length} steps)</span>
            </span>
            {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          {isOpen && (
            <div className="mt-3 pl-1 space-y-2.5 animate-fadeIn">
              <ol className="list-none space-y-2.5" role="list">
                {meal.recipeSteps.map((step, idx) => (
                  <li key={idx} className="flex gap-2.5 text-xs">
                    <span className="flex-none w-4.5 h-4.5 rounded-full bg-slate-100 text-slate-700 font-bold text-[10px] flex items-center justify-center font-mono mt-0.5 select-none" aria-hidden="true">
                      {idx + 1}
                    </span>
                    <span className="text-slate-600 leading-relaxed font-semibold">
                      {step}
                    </span>
                  </li>
                ))}
              </ol>
            </div>
          )}
        </div>
      </div>
    </article>
  );
}
