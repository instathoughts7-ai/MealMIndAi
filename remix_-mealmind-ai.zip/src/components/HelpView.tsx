import { useEffect, useRef } from 'react';
import { X, BookOpen, AlertCircle } from 'lucide-react';

interface HelpViewProps {
  onClose: () => void;
}

export function HelpView({ onClose }: HelpViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Save last focused element to restore it on unmount
    const previousFocus = document.activeElement as HTMLElement;

    if (containerRef.current) {
      const focusable = containerRef.current.querySelectorAll<HTMLElement>(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      if (focusable.length > 0) {
        // Set focus to the first focusable element inside the modal
        focusable[0].focus();
      }
    }

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        onClose();
        return;
      }

      if (e.key === 'Tab' && containerRef.current) {
        const focusable = Array.from(
          containerRef.current.querySelectorAll<HTMLElement>(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
          )
        );
        if (focusable.length === 0) return;

        const first = focusable[0];
        const last = focusable[focusable.length - 1];

        if (e.shiftKey) { // Backwards Tab
          if (document.activeElement === first) {
            last.focus();
            e.preventDefault();
          }
        } else { // Forwards Tab
          if (document.activeElement === last) {
            first.focus();
            e.preventDefault();
          }
        }
      }
    }

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (previousFocus && typeof previousFocus.focus === 'function') {
        previousFocus.focus();
      }
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        ref={containerRef}
        className="bg-white rounded-2xl shadow-2xl max-w-xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[85vh] animate-scaleUp"
        role="dialog"
        aria-modal="true"
        aria-labelledby="help-modal-title"
      >
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-5 h-5 text-emerald-400" />
            <h2 id="help-modal-title" className="text-lg font-bold tracking-tight">
              MealMind AI - Program Guide
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close guide modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          
          {/* Quick Overview */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
              Challenge Objective
            </h3>
            <p className="text-xs text-slate-605 leading-relaxed">
              Build a simple AI micro-app that prompts users for basic daily parameters (budget, family size, dietary path, pantry available stocks), aggregates costs, and produces a complete responsive single-page cooking to-do list for Breakfast, Lunch, and Dinner.
            </p>
          </div>

          {/* Quick setup steps */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
              Working with Inputs
            </h3>
            
            <div className="space-y-2.5 pl-3 border-l-2 border-emerald-500/20">
              <div className="text-xs">
                <strong className="text-slate-800 block mb-0.5">1. Budget Optimization:</strong>
                <span className="text-slate-600">Ensure the target budget fits the family size. For larger groups, scale the budget to account for bulk costs.</span>
              </div>
              <div className="text-xs">
                <strong className="text-slate-800 block mb-0.5">2. Ingredient Sanitization:</strong>
                <span className="text-slate-600">Separate stock items with commas (e.g. <em>pasta, sauce, cheese, oregano</em>). MealMind AI filters out special characters and HTML strings.</span>
              </div>
              <div className="text-xs">
                <strong className="text-slate-800 block mb-0.5">3. Day Type Constraints:</strong>
                <span className="text-slate-600">Selecting <em>Working Day</em> prompts quick, simple meals under 20-30 minutes. <em>Weekend</em> selection unlocks richer, creative cooking.</span>
              </div>
            </div>
          </div>

          {/* Tips block */}
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-100 flex gap-3 text-amber-900">
            <AlertCircle className="w-4.5 h-4.5 shrink-0 mt-0.5 text-amber-700" />
            <div className="text-xs">
              <strong className="font-bold block mb-1">Zero-Waste Zero-Cost Goal</strong>
              <p className="leading-relaxed opacity-95 font-medium">
                Double-check your fridge. Adding items you already have to the "kitchen ingredients" box enables Gemini to design recipes utilizing them directly, minimizing excess grocery bills and reducing waste.
              </p>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-4 flex items-center justify-end border-t border-slate-100 shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer"
          >
            Got it, thanks!
          </button>
        </div>
      </div>
    </div>
  );
}
