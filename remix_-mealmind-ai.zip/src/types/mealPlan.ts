/**
 * MealMind AI - Strict TypeScript interfaces for full-type safety
 */

export type DietPreference = 'Vegetarian' | 'Vegan' | 'Non-Vegetarian';
export type DayType = 'Working Day' | 'Weekend';
export type BudgetStatus = 'Within Budget' | 'Near Limit' | 'Over Budget';

export interface UserPlannerInput {
  dailyBudget: number;      // Must be positive
  familySize: number;       // Range: 1 to 100
  dietPreference: DietPreference;
  availableIngredients: string; // Long text, separated by commas or newlines
  cookingTimeAvailable: number; // In minutes, positive
  dayType: DayType;
}

export interface MealItem {
  mealName: string;
  prepTime: string; // e.g., "15 mins"
  cost: number;     // estimated total cost for the family size
  description: string;
  recipeSteps: string[];
}

export interface GroceryItem {
  name: string;
  estimatedCost: number;
  quantity: string;
}

export interface GroceryList {
  alreadyAvailable: string[];
  needToBuy: GroceryItem[];
}

export interface Substitution {
  original: string;
  substitute: string;
  reason: string;
}

export interface BudgetAnalysis {
  estimatedDailyCost: number;
  remainingBudget: number;
  budgetStatus: BudgetStatus;
  feasibilityExplanation: string;
  savingsTips: string[];
}

export interface MealPlanResponse {
  breakfast: MealItem;
  lunch: MealItem;
  dinner: MealItem;
  groceryList: GroceryList;
  substitutions: Substitution[];
  budgetAnalysis: BudgetAnalysis;
}

// Client-side execution types
export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export interface TestResult {
  name: string;
  passed: boolean;
  message?: string;
}
